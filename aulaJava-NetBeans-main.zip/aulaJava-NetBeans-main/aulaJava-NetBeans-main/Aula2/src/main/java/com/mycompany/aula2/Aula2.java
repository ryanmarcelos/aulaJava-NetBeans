/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula2;

/**
 *
 * @author aluno
 */
import javax.swing.JOptionPane;
public class Aula2 {

   public static void main(String[] args) {
       int resposta = JOptionPane.showConfirmDialog(null, "Você é casado?");
       System.out.println(resposta);
   }
}