/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Animal;

/**
 *
 * @author aluno
 */
public class Alterar {
    public static void main(String[] args){
        String frase = "Brasil vai ganhar a Copa do Mundo";
        String nova = frase.replace(" ", "_");
        System.out.println(nova);
    }
}
