/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula2;

/**
 *
 * @author aluno
 * 
 */
//Metodo sem retorno comparamentro 
public class Metodo3 {
    void mostrarNome(String nome){
        System.out.println("Nome é "+nome);
    }    
    int  calcularIdade(int atual, int nascimento){
        return atual-nascimento;
        
  }
    
}
