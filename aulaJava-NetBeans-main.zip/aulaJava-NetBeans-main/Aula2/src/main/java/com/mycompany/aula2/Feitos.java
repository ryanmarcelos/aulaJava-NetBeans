/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula2;

/**
 *
 * @author aluno
 */
public class Metodo4 {
    
 }   
    //Perguntar nome e idade
     //Scanner entrada = new Scanner(System.in);
        //System.out.println("Qual seu nome? ");
        //String palavra = entrada.nextLine();
      // System.out.println("Qual sua idade? ");
       //int numero = entrada.nextInt();
       //System.out.println("Seu nome é " + palavra + " e sua idade é " + numero);
      // entrada.close();

