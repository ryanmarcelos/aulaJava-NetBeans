/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula2;

/**
 *
 * @author aluno
 * Metodo com retorno
 */
//
public class Metodo2 {
    String nome = "Carlos";
    
    String apresentar(){
        return "Prazer, meu nome é "+nome;
    }
    
}
